java -jar flights.jar $1 $2
